﻿using Microsoft.AspNetCore.Mvc;

namespace Group1FinalProject.Controllers
{
    public class AboutController : Controller
    {
        public IActionResult About()
        {
            return View();
        }
    }
}
